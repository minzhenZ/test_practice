import os
import unittest

from BeautifulReport import BeautifulReport
from tomorrow import threads

from case.test_task import TestTask


def load_testcase(testfile):
    moudules = unittest.TestLoader().discover('./case', testfile)
    testlst = [test for suites in moudules for tests in suites for test in tests]
    return testlst

@threads(10)
def run_testcase(testcase, counts):

    result = BeautifulReport(testcase)
    result.report(counts, '测试报告', filename='report.html')

if __name__ == '__main__':

    tests = load_testcase('test*.py')

    for i in tests:
        run_testcase(i, len(tests))