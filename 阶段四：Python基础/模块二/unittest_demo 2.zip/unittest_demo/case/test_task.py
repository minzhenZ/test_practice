
import HTMLTestRunner_PY3
from threadpool import ThreadPool, makeRequests

import time
import unittest, threading

def test_task(name):
    print(f"{threading.current_thread().name}:", name)
    time.sleep(10)

class TestTask(unittest.TestCase):
    def test01(self):
        test_task(1)
    def test02(self):
        test_task(2)
    def test03(self):
        test_task(3)
    def test04(self):
        test_task(4)
    def test05(self):
        test_task(5)
    def test06(self):
        test_task(6)
    def test07(self):
        test_task(7)
    def test08(self):
        test_task(8)
    def test09(self):
        test_task(9)
    def test10(self):
        test_task(10)


