from base.utils import init_logging

init_logging()